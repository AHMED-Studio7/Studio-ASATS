/*
# Create news platform schema with categories, articles, sources, and editors

1. New Tables
- `categories` — news sections (أخبار، اقتصاد، تكنولوجيا، تحقيقات، برامج، رياضة، صحة، ثقافة)
  - id (uuid PK), name (text), slug (text unique), created_at
- `sources` — original news sources for credibility tracking
  - id (uuid PK), name (text), url (text), logo_url (text), created_at
- `editors` — platform editors/journalists
  - id (uuid PK), name (text), avatar_url (text), role (text), bio (text), created_at
- `articles` — full news articles with newspaper-style content
  - id (uuid PK), title (text), excerpt (text lead paragraph), content (text full body),
    image_url (text), image_caption (text), category_id (FK), source_id (FK), editor_id (FK),
    is_featured (bool), is_live (bool), views (int), published_at (timestamptz), created_at
2. Security
- All tables are single-tenant (no auth) → RLS enabled with anon+authenticated full CRUD
  since the platform is a public news site with a separate admin dashboard.
3. Seed Data
- 8 categories, 5 sources, 4 editors, 15+ articles across all categories
*/

-- Categories
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_categories" ON categories;
CREATE POLICY "anon_select_categories" ON categories FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_categories" ON categories;
CREATE POLICY "anon_insert_categories" ON categories FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_categories" ON categories;
CREATE POLICY "anon_update_categories" ON categories FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_categories" ON categories;
CREATE POLICY "anon_delete_categories" ON categories FOR DELETE TO anon, authenticated USING (true);

-- Sources
CREATE TABLE IF NOT EXISTS sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  url text,
  logo_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE sources ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_sources" ON sources;
CREATE POLICY "anon_select_sources" ON sources FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_sources" ON sources;
CREATE POLICY "anon_insert_sources" ON sources FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_sources" ON sources;
CREATE POLICY "anon_update_sources" ON sources FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_sources" ON sources;
CREATE POLICY "anon_delete_sources" ON sources FOR DELETE TO anon, authenticated USING (true);

-- Editors
CREATE TABLE IF NOT EXISTS editors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  avatar_url text,
  role text,
  bio text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE editors ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_editors" ON editors;
CREATE POLICY "anon_select_editors" ON editors FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_editors" ON editors;
CREATE POLICY "anon_insert_editors" ON editors FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_editors" ON editors;
CREATE POLICY "anon_update_editors" ON editors FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_editors" ON editors;
CREATE POLICY "anon_delete_editors" ON editors FOR DELETE TO anon, authenticated USING (true);

-- Articles
CREATE TABLE IF NOT EXISTS articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  excerpt text NOT NULL,
  content text NOT NULL,
  image_url text,
  image_caption text,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  source_id uuid REFERENCES sources(id) ON DELETE SET NULL,
  editor_id uuid REFERENCES editors(id) ON DELETE SET NULL,
  is_featured boolean DEFAULT false,
  is_live boolean DEFAULT false,
  views integer DEFAULT 0,
  published_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_articles" ON articles;
CREATE POLICY "anon_select_articles" ON articles FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_articles" ON articles;
CREATE POLICY "anon_insert_articles" ON articles FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_articles" ON articles;
CREATE POLICY "anon_update_articles" ON articles FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_articles" ON articles;
CREATE POLICY "anon_delete_articles" ON articles FOR DELETE TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_articles_featured ON articles(is_featured);

-- Seed categories
INSERT INTO categories (name, slug) VALUES
  ('أخبار', 'news'),
  ('اقتصاد', 'economy'),
  ('تكنولوجيا', 'technology'),
  ('تحقيقات', 'investigations'),
  ('برامج', 'programs'),
  ('رياضة', 'sports'),
  ('صحة', 'health'),
  ('ثقافة', 'culture')
ON CONFLICT (slug) DO NOTHING;

-- Seed sources
INSERT INTO sources (name, url) VALUES
  ('وكالة الأنباء الدولية', 'https://example.com/intl-news'),
  ('رويترز', 'https://example.com/reuters'),
  ('بلومبرغ', 'https://example.com/bloomberg'),
  ('فرانس برس', 'https://example.com/afp'),
  ('سكاي نيوز', 'https://example.com/skynews')
ON CONFLICT DO NOTHING;

-- Seed editors
INSERT INTO editors (name, role, bio) VALUES
  ('أحمد المنصوري', 'رئيس التحرير', 'صحفي مخضضم بخبرة تتجاوز عشرين عاماً في تغطية الأحداث السياسية الدولية'),
  ('سارة الحسن', 'محللة اقتصادية', 'متخصصة في الأسواق المالية والاقتصاد العالمي، حاصلة على دكتوراه في الاقتصاد'),
  ('خالد العتيبي', 'محرر التكنولوجيا', 'مهتم بالابتكار التقني والذكاء الاصطناعي وأثرهما على المجتمعات'),
  ('ليلى كريم', 'محررة التحقيقات', 'صحفية استقصائية حائزة على جوائز عربية في الصحافة الاستقصائية')
ON CONFLICT DO NOTHING;

-- Seed articles using subqueries for IDs
DO $$
DECLARE
  v_news uuid; v_economy uuid; v_tech uuid; v_invest uuid; v_programs uuid;
  v_sports uuid; v_health uuid; v_culture uuid;
  v_src1 uuid; v_src2 uuid; v_src3 uuid; v_src4 uuid; v_src5 uuid;
  v_ed1 uuid; v_ed2 uuid; v_ed3 uuid; v_ed4 uuid;
BEGIN
  SELECT id INTO v_news FROM categories WHERE slug='news';
  SELECT id INTO v_economy FROM categories WHERE slug='economy';
  SELECT id INTO v_tech FROM categories WHERE slug='technology';
  SELECT id INTO v_invest FROM categories WHERE slug='investigations';
  SELECT id INTO v_programs FROM categories WHERE slug='programs';
  SELECT id INTO v_sports FROM categories WHERE slug='sports';
  SELECT id INTO v_health FROM categories WHERE slug='health';
  SELECT id INTO v_culture FROM categories WHERE slug='culture';

  SELECT id INTO v_src1 FROM sources WHERE name='وكالة الأنباء الدولية';
  SELECT id INTO v_src2 FROM sources WHERE name='رويترز';
  SELECT id INTO v_src3 FROM sources WHERE name='بلومبرغ';
  SELECT id INTO v_src4 FROM sources WHERE name='فرانس برس';
  SELECT id INTO v_src5 FROM sources WHERE name='سكاي نيوز';

  SELECT id INTO v_ed1 FROM editors WHERE name='أحمد المنصوري';
  SELECT id INTO v_ed2 FROM editors WHERE name='سارة الحسن';
  SELECT id INTO v_ed3 FROM editors WHERE name='خالد العتيبي';
  SELECT id INTO v_ed4 FROM editors WHERE name='ليلى كريم';

  INSERT INTO articles (title, excerpt, content, image_url, image_caption, category_id, source_id, editor_id, is_featured, is_live, published_at) VALUES
  -- Featured news
  ('قمة عالمية طارئة لبحث الأزمة الدبلوماسية المتصاعدة في الشرق الأوسط',
   'تدعو الجامعة العربية إلى قمة طارئة غداً بحضور قادة كبار لمناقشة التصعيد المتواصل وسبل احتواء التوترات قبل تفاقمها إلى مواجهة مفتوحة.',
   'أعلنت الجامعة العربية اليوم عن دعوة عاجلة لقمة قيادية طارئة تعقد غداً في مقر الأمانة العامة بالقاهرة، بحضور عدد من قادة الدول ورؤساء الحكومات لمناقشة التطورات المتسارعة على الساحة الإقليمية.

وقال الأمين العام للجامعة العربية في بيان مقتضب إن القمة تأتي في ظل تدهور غير مسبوق في العلاقات الدبلوماسية بين عدة دول إقليمية، مشيراً إلى أن الوضع يتطلب تدخلاً سياسياً عاجلاً لمنع انزلاق المنطقة نحو مواجهة شاملة.

من جانبها، أصدرت وزارة الخارجية الأمريكية بياناً رحبت فيه بمبادرة القمة، مؤكدة أن واشنطن سترسل مبعوثاً خاصاً للمشاركة في المشاورات. كما أعلنت فرنسا وبريطانيا عن استعدادهما للمساهمة في الجهود الدبلوماسية.

ويفسر مراقبون هذه التحركات الدبلوماسية المكثفة بأنها محاولة لاحتواء أزمة بدأت تتسارع منذ أيام، وسط مخاوف من تأثيرها على الملاحة الدولية وأسواق الطاقة العالمية.

يأتي هذا التطور في وقت حساس، حيث تتجه الأنظار نحو مجلس الأمن الذي يُتوقع أن يعقد جلسة مغلقة لمناقشة الوضع في ضوء التطورات الميدانية الأخيرة.',
   'https://images.pexels.com/photos/8850837/pexels-photo-8850837.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'صورة تعبيرية للأزمة الدبلوماسية العالمية — تصوير: تارا وينسيد',
   v_news, v_src1, v_ed1, true, true, now() - interval '2 hours'),

  ('الأسواق العالمية تتراجع وسط مخاوف من ركود اقتصادي قادم',
   'انهارت مؤشرات وال ستريت بنسبة 3.2% خلال تعاملات اليوم، متأثرة ببيانات تضخمية مخيبة للآمال وتصريحات متشددة من الفيدرالي الأمريكي.',
   'شهدت الأسواق المالية العالمية اليوم موجة بيع واسعة النطاق، حيث تراجعت مؤشرات وال ستريت الرئيسية بنحو 3.2% مع إغلاق تعاملات اليوم، في أكبر هبوط يومي منذ أشهر.

وجاء التراجع عقب صدور بيانات التضخم الأمريكية التي أظهرت ارتفاعاً أعلى من المتوقع، مما عزز التكهنات بأن مجلس الاحتياطي الفيدرالي قد يواصل تشديد سياسته النقدية لفترة أطول مما كان متوقعاً.

وأكد محافظ البنك المركزي الأمريكي في تصريحاته أمام الكونغرس أن مكافحة التضخم تبقى الأولوية القصوى، مشيراً إلى أن البنك مستعد لاتخاذ خطوات حازمة إذا استمرت الضغوط السعرية.

وعلى صعيد الأسواق الآسيوية، تراجع مؤشر نيكاي الياباني بنحو 2.8%، بينما هبط مؤشر هانغ سنغ في هونغ كونغ بنسبة 3.1%. كذلك تأثرت الأسواق الأوروبية حيث خسر مؤشر فوتسي 100 البريطاني نحو 2.5% من قيمته.

وأبدى خبراء اقتصاد مخاوفهم من أن هذا التراجع قد يكون مؤشراً على بداية مرحلة ركود اقتصادي، خاصة في ظل ارتفاع تكاليف الاقتراض وتباطؤ النمو في كبرى الاقتصادات العالمية.',
   'https://images.pexels.com/photos/35118208/pexels-photo-35118208.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'رسم بياني يوضح تراجع الأسواق المالية — تصوير: أليكس لونا',
   v_economy, v_src3, v_ed2, true, false, now() - interval '5 hours'),

  ('اختراق علمي: ذكاء اصطناعي يكتشف أمراضاً نادرة بدقة تفوق الأطباء',
   'كشفت دراسة دولية عن نموذج ذكاء اصطناعي جديد قادر على تشخيص 47 مرضاً نادراً بدقة تصل إلى 96%، مما يفتح آفاقاً جديدة في الطب الشخصي.',
   'في إنجاز علمي وصفه الخبراء بالثوري، كشفت دراسة دولية مشتركة عن نموذج ذكاء اصطناعي جديد قادر على تشخيص 47 مرضاً نادراً بدقة تصل إلى 96%، متفوقاً بذلك على الأطباء البشريين في سرعة ودقة التشخيص.

وأجرى الباحثون من ثماني جامعات حول العالم الدراسة على أكثر من 12 ألف حالة طبية، حيث تم تدريب النموذج على قاعدة بيانات ضخمة تتضمن صوراً طبية وتحاليل جينية وسجلات سريرية.

وقال كبير الباحثين في الدراسة إن هذا الاكتشاف يمثل نقطة تحول في التعامل مع الأمراض النادرة، التي غالباً ما يستغرق تشخيصها سنوات بسبب ندرة الخبرة الطبية المتخصصة في هذا المجال.

يُذكر أن منظمة الصحة العالمية تقدر عدد الأشخاص الذين يعانون من أمراض نادرة بنحو 300 مليون شخص على مستوى العالم، وكثير منهم ينتظرون سنوات قبل الحصول على تشخيص دقيق لحالتهم.

وأكد الباحثون أن النموذج لن يحل محل الأطباء، بل سيعمل كأداة مساعدة تساعد في تسريع عملية التشخيص وتمكين الأطباء من اتخاذ قرارات علاجية أكثر دقة وفي وقت مبكر.',
   'https://images.pexels.com/photos/9574505/pexels-photo-9574505.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'باحث يعمل على تحليل عينات في المختبر — تصوير:تيما مروشينينكو',
   v_tech, v_src2, v_ed3, true, false, now() - interval '8 hours'),

  ('تحقيق استقصائي: شبكة دولية لتهريب الآثار التاريخية من المنطقة العربية',
   'كشف تحقيق استقصائي استمر ثمانية أشهر عن شبكة دولية منظمة تقوم بتهريب آثار تاريخية نادرة من عدة دول عربية وبيعها في أسواق سرية حول العالم.',
   'في تحقيق استقصائي استمر ثمانية أشهر وامتد عبر خمس قارات، كشف فريق من الصحفيين الاستقصائيين عن شبكة دولية منظمة تقوم بتهريب آثار تاريخية نادرة من عدة دول عربية وبيعها في أسواق سرية حول العالم.

واعتمد التحقيق على تحليل آلاف الوثائق والمستندات، ومقابلات مع مصادر من داخل الشبكة، بالإضافة إلى تتبع مالي معقد لعمليات بيع بلغت قيمتها ملايين الدولارات.

وكشف التحقيق أن الشبكة تعمل عبر حلقات مترابطة في أكثر من 12 دولة، حيث تقوم مجموعات مسلحة بالاستيلاء على المواقع الأثرية في مناطق النزاع، قبل أن تنقل هذه الآثار عبر طرق تهريب معقدة تمر عبر موانئ متعددة لإخفاء مصدرها الأصلي.

ووفق الوثائق التي حصل عليها التحقيق، فإن بعض القطع الأثرية المسروقة تعود لحضارات يعود تاريخها لآلاف السنين، وقد ظهر بعضها في مزادات علنية كبرى تحت مصادر مزورة.

ودعت المنظمات الدولية المعنية بحماية التراث إلى تكثيف الجهود الدولية لوقف هذه التجارة غير المشروعة، وإعادة الآثار المسروقة إلى دولها الأصلية.',
   'https://images.pexels.com/photos/8369518/pexels-photo-8369518.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'صورة تعبيرية للتحقيق الاستقصائي — تصوير: كوتونبرو ستوديو',
   v_invest, v_src4, v_ed4, false, false, now() - interval '12 hours'),

  ('برنامج حصري: حوار مع وزير التخطيط حول رؤية التنمية المستدامة',
   'في حوار تلفزيوني حصري، يكشف وزير التخطيط عن ملامح الرؤية الجديدة للتنمية المستدامة وأبرز التحديات التي تواجه مسيرة التنويع الاقتصادي.',
   'يستضيف برنامج "حوار مفتوح" في حلقة خاصة وزير التخطيط والتنمية الاقتصادية للحديث عن الرؤية الجديدة للتنمية المستدامة التي أعلنتها الحكومة مؤخراً.

ويتطرق الحوار إلى عدة محاور رئيسية، أبرزها خطط التنويع الاقتصادي وتقليل الاعتماد على مصادر دخل واحدة، وكذلك البرامج الطموحة في مجالات التعليم والصحة والبنية التحتية.

كما يناقش الوزير التحديات التي تواجه مسيرة التنمية، خاصة في ظل التقلبات الاقتصادية العالمية وتأثيراتها على الاقتصادات الناشئة.

يُذكر أن الرؤية الجديدة تستهدف رفع نسبة مساهمة القطاع الخاص في الناتج المحلي إلى 65% خلال السنوات العشر المقبلة، وتوفير ملايين فرص العمل للشباب.',
   'https://images.pexels.com/photos/39332193/pexels-photo-39332193.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'استوديو البث التلفزيوني — تصوير: نفتوغ يالتشين',
   v_programs, v_src5, v_ed1, false, false, now() - interval '18 hours'),

  ('نهائي بطولة كرة القدم: مواجهة تاريخية بين عملاقي الكرة العالمية',
   'تشهد عاصمة كبرى اليوم نهائي بطولة كرة القدم الأهم هذا الموسم، في مواجهة تاريخية بين فريقين يجمعان بينهما 15 لقباً قارياً.',
   'تحت أضواء ملعب يتسع لأكثر من 80 ألف متفرج، تشهد العاصمة اليوم نهائي بطولة كرة القدم الأهم هذا الموسم، في مواجهة تاريخية بين فريقين يجمعان بينهما 15 لقباً قارياً.

ويدخل الفريقان المباراة بحالة فنية ممتازة، حيث حقق كل منهما فوزاً كبيراً في نصف النهائي. ويترقب عشاق الكرة حول العالم هذا اللقاء الذي يُتوقع أن يشهد إثارة footballية كبيرة.

وقال مدرب أحد الفريقين في المؤتمر الصحفي قبيل المباراة إن فريقه جاهز تماماً وأن اللاعبين على دراية تامة بأهمية المباراة وحجم المسؤولية.

من جانبه، أكد مدرب الفريق المنافس أن مباريات النهائي لها حسابات خاصة، وأن الاستعداد النفسي لا يقل أهمية عن الاستعداد البدني والفني.

وتشهد المباراة حضوراً جماهيرياً كبيراً، حيث بيعت جميع التذاكر المتاحة قبل أيام من الموعد، كما يُتوقع أن يشاهدها أكثر من مليار مشاهد حول العالم عبر الشاشات.',
   'https://images.pexels.com/photos/30651230/pexels-photo-30651230.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'ملعب كرة القدم تحت الأضواء — تصوير: جورج زوغرافديس',
   v_sports, v_src1, v_ed2, false, true, now() - interval '1 hour'),

  ('دراسة طبية جديدة: الصيام المتقطع قد يقلل من خطر الإصابة بأمراض القلب',
   'كشفت دراسة طبية حديثة شملت 20 ألف مشارك أن الصيام المتقطع لمدة 16 ساعة يومياً قد يساهم في تقليل خطر الإصابة بأمراض القلب بنسبة تصل إلى 25%.',
   'كشفت دراسة طبية حديثة نشرت في مجلة طبية دولية مرموقة أن الصيام المتقطع لمدة 16 ساعة يومياً قد يساهم في تقليل خطر الإصابة بأمراض القلب بنسبة تصل إلى 25%.

وشملت الدراسة التي استمرت ثلاث سنوات أكثر من 20 ألف مشارك تتراوح أعمارهم بين 30 و65 عاماً، تم تقسيمهم إلى مجموعتين: الأولى تتبع نظام الصيام المتقطع، والثانية تتبع نظام التغذية المعتاد.

وأظهرت النتائج أن المجموعة التي اتبعت نظام الصيام المتقطع شهدت تحسناً ملموساً في مؤشرات صحة القلب، بما في ذلك انخفاض مستويات الكوليسترول الضار وضغط الدم والتهابات الجسم.

وحذر الباحثون من أن الصيام المتقطع قد لا يكون مناسباً للجميع، خاصة المصابين بأمراض مزمنة أو النساء الحوامل وكبار السن، مؤكدين على ضرورة استشارة الطبيب قبل اتباع أي نظام غذائي جديد.

ويأمل الباحثون في إجراء دراسات أوسع لفهم الآليات البيولوجية التي يؤثر من خلالها الصيام المتقطع على صحة القلب والأوعية الدموية.',
   'https://images.pexels.com/photos/356040/pexels-photo-356040.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'عالم يبحث في المختبر — تصوير: بيكساباي',
   v_health, v_src2, v_ed3, false, false, now() - interval '20 hours'),

  ('معرض فني عالمي يستضيف أعمالاً لفنانين عرب معاصرين',
   'يفتتح في متحف الفن الحديث الأسبوع القادم معرضاً فنياً ضخماً يستضيف أعمال أكثر من 40 فناناً عربياً معاصراً، في حدث يُعد الأكبر من نوعه.',
   'يفتتح في متحف الفن الحديث الأسبوع القادم معرضاً فنياً ضخماً يستضيف أعمال أكثر من 40 فناناً عربياً معاصراً، في حدث يُعد الأكبر من نوعه على مستوى المعارض الفنية العربية الدولية.

ويتضمن المعرض الذي يحمل عنوان "هوية وذاكرة" أكثر من 150 عملاً فنياً متنوعاً بين الرسم والنحت والتصوير الفوتوغرافي والفن الرقمي، يعكس تنوع التجارب الإبداعية في المنطقة العربية.

وقال منظم المعرض إن الحدث يهدف إلى تسليط الضوء على الإبداع العربي المعاصر وإتاحة الفرصة للفنانين للوصول إلى جمهور عالمي، مشيراً إلى أن المعرض سيستمر لمدة ثلاثة أشهر.

كما تُنظم على هامش المعرض ندوات وحوارات فنية يشارك فيها نقاد وفنانون من مختلف الدول، إلى جانب ورش عمل تفاعلية للزوار مهتمين بالفنون البصرية.',
   'https://images.pexels.com/photos/29608796/pexels-photo-29608796.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'متحف الفن الحديث — تصوير: محمد ألجي',
   v_culture, v_src4, v_ed4, false, false, now() - interval '1 day'),

  ('مؤتمر المناخ العالمي يختتم أعماله ببيان ختامي حاسم',
   'اختتم مؤتمر المناخ العالمي أعماله بعد أسبوعين من المفاوضات المكثفة، ببيان ختامي يلتزم فيه المشاركون بتعهدات طموحة لخفض الانبعاثات الكربونية.',
   'اختتم مؤتمر المناخ العالمي أعماله اليوم بعد أسبوعين من المفاوضات المكثفة بين وفود 195 دولة، ببيان ختامي يلتزم فيه المشاركون بتعهدات طموحة لخفض الانبعاثات الكربونية والوصول إلى الحياد الكربوني بحلول عام 2050.

ودعا البيان الختامي الدول المتقدمة إلى تقديم دعم مالي أكبر للدول النامية لمساعدتها في التعامل مع آثار التغير المناخي، حيث تم الاتفاق على إنشاء صندوق للخسائر والأضرار بقيمة 200 مليار دولار سنوياً.

كما أكد البيان على ضرورة تسريع التحول نحو مصادر الطاقة المتجددة، مع التزام الدول الأعضاء بثلاثة أضعاف قدرات الطاقة المتجددة العالمية بحلول عام 2030.

ومع ذلك، أعربت بعض الدول النامية عن خيبة أملها من أن التعهدات المالية لم ترقَ إلى مستوى الطموحات، مطالبة بآليات تنفيذ أكثر صرامة لضمان التزام الدول المتقدمة بوعودها.

يأتي هذا المؤتمر في وقت حرج، حيث حذرت تقارير علمية حديثة من أن العالم يتجه نحو ارتفاع درجة الحرارة بنحو 2.8 درجة مئوية إذا لم تتخذ إجراءات حاسمة وفورية.',
   'https://images.pexels.com/photos/39902790/pexels-photo-39902790.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'طبيعة خضراء ترمز للمناخ — تصوير: زور تاكجيريف',
   v_news, v_src5, v_ed1, false, false, now() - interval '1 day'),

  ('الذهب يسجل مستوى قياسياً جديداً وسط تراجع الدولار',
   'سجلت أسعار الذهب عالمياً مستوى قياسياً جديداً اليوم، حيث تجاوز الأونسة حاجز 2400 دولار لأول مرة في التاريخ، وسط تراجع حاد في قيمة الدولار الأمريكي.',
   'سجلت أسعار الذهب عالمياً مستوى قياسياً جديداً اليوم، حيث تجاوزت الأونسة حاجز 2400 دولار لأول مرة في التاريخ، وسط تراجع حاد في قيمة الدولار الأمريكي وارتفاع الطلب على الملاذات الآمنة.

وأرجع محللون هذا الار.record إلى عدة عوامل، أبرزها تراجع قيمة الدولار الأمريكي مقابل سلة من العملات الرئيسية، وتزايد التكهنات بأن مجلس الاحتياطي الفيدرالي قد يبدأ في خفض أسعار الفائدة خلال الأشهر المقبلة.

كما ساهمت المخاوف الجيوسياسية وعدم اليقين بشأن الاقتصاد العالمي في تعزيز الطلب على الذهب كملاذ آمن، حيث تتزايد مشتريات البنوك المركزية للمعادن النفيسة.

محلياً، ارتفعت أسعار الذهب في أسواق المنطقة العربية تماشياً مع الأسعار العالمية، مما أثر على حجم الطلب في الأسواق المحلية، حيث اتجه بعض المستثمرين إلى تأجيل مشترياتهم على أمل تراجع الأسعار.',
   'https://images.pexels.com/photos/534216/pexels-photo-534216.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'شاشة الأسواق المالية — تصوير: بيكساباي',
   v_economy, v_src3, v_ed2, false, false, now() - interval '1 day'),

  ('شركة تقنية كبرى تكشف عن معالج جديد بسرعات قياسية',
   'أعلنت شركة تقنية رائدة اليوم عن معالج جديد من الجيل القادم، يقدم سرعات تفوق ما هو متاح في السوق بنسبة 40%، مع استهلاك أقل للطاقة.',
   'أعلنت شركة تقنية رائدة اليوم عن معالج جديد من الجيل القادم، يقدم سرعات تفوق ما هو متاح في السوق حالياً بنسبة 40%، مع استهلاك أقل للطاقة بنسبة 25%.

وقال الرئيس التنفيذي للشركة في مؤتمر صحفي إن المعالج الجديد يستخدم تقنية حديثة في تصنيع الشرائح بحجم 3 نانومتر، مما يسمح بحزم عدد أكبر من الترانزستورات في مساحة أصغر.

وأضاف أن المعالج مصمم خصيصاً لتسريع عمليات الذكاء الاصطناعي والتعلم الآلي، حيث يحتوي على وحدة معالجة عصبية متطورة قادرة على تنفيذ 40 تريليون عملية في الثانية.

من المتوقع أن تدخل الشرائح الجديدة حيز الإنتاج التجاري خلال الربع الأول من العام المقبل، وستُستخدم في البداية في خوادم مراكز البيانات الكبرى قبل أن تتوفر للأجهزة الشخصية.',
   'https://images.pexels.com/photos/16027824/pexels-photo-16027824.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'شاشة حاسوب تعرض واجهة ذكاء اصطناعي — تصوير: ماثيوس بيرتيلي',
   v_tech, v_src2, v_ed3, false, false, now() - interval '1 day'),

  ('تحقيق: ظاهرة الهجرة العكسية تجذب الكفاءات العربية للعودة',
   'في تحقيق موسع، يرصد مراسلونا ظاهرة متنامية لعودة الكفاءات العربية المهاجرة إلى بلدانها الأصلية، مدفوعة بفرص جديدة وتغير في الأولويات.',
   'في تحقيق موسع شمل عدة دول عربية، يرصد مراسلونا ظاهرة متنامية لعودة الكفاءات العربية المهاجرة إلى بلدانها الأصلية، في ما يُعرف بـ"الهجرة العكسية".

وتشير بيانات رسمية إلى أن أعداد العائدين تضاعفت خلال السنوات الثلاث الماضية، حيث اختار آلاف الكفاءات العربية من أطباء ومهندسين وباحثين العودة إلى بلدانهم.

ويلتقي التحقيق مع عدة شخصيات عادت من دول غربية، يروون تجاربهم وأسباب عودتهم، التي تتراوح بين الرغبة في المساهمة في تنمية بلدانهم، والشوق للوطن، وعدم الرضا عن بيئة العمل في المهجر.

كما يستعرض التحقيق التحديات التي يواجهها العائدون، مثل الفجوة في الأجور وصعوبة التأقلم من جديد، إلى جانب البرامج الحكومية التي تُسهل عودة الكفاءات وتوفر لهم بيئة عمل مناسبة.',
   'https://images.pexels.com/photos/19127799/pexels-photo-19127799.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'مدينة كابول من الجو — تصوير: قاسم ميرزائي',
   v_invest, v_src4, v_ed4, false, false, now() - interval '2 days'),

  ('برنامج وثائقي: رحلة داخل مدن ذكية تُدار بالكامل بالذكاء الاصطناعي',
   'يستعرض برنامج وثائقي جديد تجربة ثلاث مدن حول العالم تُدار بالكامل بأنظمة الذكاء الاصطناعي، من المرور إلى النظافة إلى الرعاية الصحية.',
   'يستعرض برنامج وثائقي جديد تجربة ثلاث مدن حول العالم تُدار بالكامل بأنظمة الذكاء الاصطناعي، من إدارة المرور والنقل إلى النظافة والرعاية الصحية والأمن.

ويأخذ البرنامج المشاهدين في رحلة داخل هذه المدن، حيث تتحكم أنظمة ذكية في كل تفاصيل الحياة اليومية، من إشارات المرور التي تتكيف مع كثافة الحركة لحظياً، إلى روبوتات تنظيف الشوارع، وأنظمة مراقبة صحية تنبئ بالأمراض قبل وقوعها.

ويرصد البرنامج كذلك الجدل الأخلاقي حول هذه المدن، حيث يطرح تساؤلات حول الخصوصية وحقوق الإنسان في عالم تُراقب فيه كل حركة وكل نظرة.

يُعرض البرنامج الوثائقي يوم الجمعة في تمام الساعة التاسعة مساءً، ويمكن مشاهدة الحلقات السابقة عبر التطبيق الرقمي للموقع.',
   'https://images.pexels.com/photos/8721342/pexels-photo-8721342.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'شخص يرتدي نظارة واقع افتراضي — تصوير: كوتونبرو ستوديو',
   v_programs, v_src5, v_ed3, false, false, now() - interval '2 days'),

  ('اكتشاف أثري: العثور على مدينة埋 ing مدفونة عمرها 3000 عام',
   'أعلن فريق أثري دولي عن اكتشاف مدينة كاملة مدفونة تحت الرمال عمرها أكثر من 3000 عام، في ما يُعد أحد أهم الاكتشافات الأثرية في العصر الحديث.',
   'أعلن فريق أثري دولي اليوم عن اكتشاف مدينة كاملة مدفونة تحت الرمال عمرها أكثر من 3000 عام، في ما يُعد أحد أهم الاكتشافات الأثرية في العصر الحديث.

وقال رئيس الفريق الأثري إن المدينة التي تم اكتشافها تمتد على مساحة تزيد عن 5 كيلومترات مربعة، وتضم مباني سكنية ومعابد وقصوراً ومنشآت تجارية، بعضها في حالة حفظ مذهلة.

وأضاف أن الاكتشاف يلقي ضوءاً جديداً على حضارة كانت مجهولة حتى الآن، حيث عثر على آلاف النقوش والوثائق التي تساعد في فهم الحياة الاجتماعية والاقتصادية والدينية في تلك الحقبة.

من المخطط أن يبدأ الفريق في ترميم الموقع وفتحه للزوار خلال السنوات الثلاث المقبلة، حيث يُتوقع أن يتحول إلى واحد من أهم المواقع الأثرية في المنطقة.',
   'https://images.pexels.com/photos/30311891/pexels-photo-30311891.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'آثار تاريخية في متحف — تصوير: هوي نغوين',
   v_culture, v_src1, v_ed1, false, false, now() - interval '2 days'),

  ('بطولة العالم لألعاب القلب: أرقام قياسية في اليوم الأول',
   'شهد اليوم الأول من بطولة العالم لألعاب القلب تحطيم ثلاثة أرقام قياسية عالمية، في بداية واعدة لبطولة تشارك فيها أكثر من 200 دولة.',
   'شهد اليوم الأول من بطولة العالم لألعاب القلب تحطيم ثلاثة أرقام قياسية عالمية، في بداية واعدة لبطولة تشارك فيها أكثر من 200 دولة.

وحقق بطل العالم في سباق 100 متر العدو رقماً قياسياً جديداً بزمن 9.56 ثانية، محطماً الرقم السابق الذي كان صامداً منذ خمسة عشر عاماً.

كما حُطم الرقم القياسي في سباق 400 متر حواجز، ووث Triple Jump، حيث أبدى الجمهور الحاضر إعجابه الشديد بالأداء الاستثنائي للرياضيين.

تستمر البطولة على مدى أسبعة أيام، ويُتوقع أن تشهد المزيد من الأرقام القياسية في الأيام المقبلة، حيث يتواجد نخبة من الرياضيين حول العالم.',
   'https://images.pexels.com/photos/33210166/pexels-photo-33210166.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'ملعب كرة قدم — تصوير: لي شيان شينغ',
   v_sports, v_src2, v_ed2, false, false, now() - interval '3 days'),

  ('منظمة الصحة العالمية تطلق حملة عالمية لمكافحة السكري',
   'أطلقت منظمة الصحة العالمية اليوم حملة عالمية شاملة لمكافحة داء السكري، الذي يصيب نحو 460 مليون شخص حول العالم، ويُسبب millions of deaths annually.',
   'أطلقت منظمة الصحة العالمية اليوم حملة عالمية شاملة لمكافحة داء السكري، الذي يصيب نحو 460 مليون شخص حول العالم، ويُسبب ملايين الوفيات سنوياً.

وتستهدف الحملة التي تحمل شعار "حياة بلا سكري" رفع الوعي بمخاطر المرض وأهمية الكشف المبكر، إلى جانب دعم الحكومات في وضع سياسات فعالة للوقاية منه.

وقال مدير عام المنظمة إن مرض السكري بات واحداً من أكبر التحديات الصحية في عصرنا الحالي، مشيراً إلى أن عدد المصابين تضاعف خلال العشرين عاماً الماضية.

تشمل الحملة برامج توعية في أكثر من 100 دولة، وتوزيع أجهزة قياس السكر مجاناً في المناطق الفقيرة، وتدريب الكوادر الصحية على الكشف المبكر عن المرض.',
   'https://images.pexels.com/photos/11589239/pexels-photo-11589239.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
   'معدات طبية في المختبر — تصوير: بيلان فيلميس',
   v_health, v_src5, v_ed3, false, false, now() - interval '3 days');
END $$;