import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

interface RSSItem {
  title: string;
  link: string;
  description: string;
  pubDate: string;
  enclosure?: string;
}

function parseRSS(xml: string): RSSItem[] {
  const items: RSSItem[] = [];
  const itemRegex = /<item[\s\S]*?<\/item>/gi;
  const matches = xml.match(itemRegex) || [];

  for (const match of matches.slice(0, 10)) {
    const getTag = (tag: string): string => {
      const regex = new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`, 'i');
      const m = match.match(regex);
      return m ? m[1].trim().replace(/<!\[CDATA\[|\]\]>/g, '') : '';
    };

    const enclosureMatch = match.match(/<enclosure[^>]*url="([^"]+)"/i);

    items.push({
      title: getTag('title'),
      link: getTag('link'),
      description: getTag('description').replace(/<[^>]+>/g, '').slice(0, 300),
      pubDate: getTag('pubDate'),
      enclosure: enclosureMatch ? enclosureMatch[1] : undefined,
    });
  }

  return items;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { source_url, category_id, source_id } = await req.json();

    if (!source_url) {
      return new Response(
        JSON.stringify({ error: "source_url is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const response = await fetch(source_url, {
      headers: { "User-Agent": "NewsBot/1.0" },
    });

    if (!response.ok) {
      return new Response(
        JSON.stringify({ error: `Failed to fetch RSS: ${response.status}` }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const xml = await response.text();
    const items = parseRSS(xml);

    let inserted = 0;
    for (const item of items) {
      if (!item.title) continue;

      const { error } = await supabase.from("articles").insert({
        title: item.title,
        excerpt: item.description || '',
        content: item.description || item.title,
        image_url: item.enclosure || null,
        image_caption: null,
        category_id: category_id || null,
        source_id: source_id || null,
        is_featured: false,
        is_live: false,
        published_at: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
      });

      if (!error) inserted++;
    }

    return new Response(
      JSON.stringify({ success: true, fetched: items.length, inserted }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
